import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface ReviewModel {
  id:        number;
  rating:    number;
  comment:   string;
  createdAt: string;
  user:      { id: number };
  hotel:     { id: number };
}

@Injectable({ providedIn: 'root' })
export class ReviewService {
  private base = 'http://localhost:9090/api/reviews';

  /** GET /api/reviews  – all reviews (any hotel) */
  listAll(): Observable<ReviewModel[]> {
    return this.http.get<ReviewModel[]>(this.base);
  }

  /** POST /api/reviews/{hotelId}?rating=&comment= */
  addReview(hotelId: number, rating: number, comment: string): Observable<ReviewModel> {
    const params = new HttpParams()
      .set('rating', rating.toString())
      .set('comment', comment);
    return this.http.post<ReviewModel>(`${this.base}/${hotelId}`, null, { params });
  }

  constructor(private http: HttpClient) {}
}
