import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

const API = 'http://localhost:9090/api/bookings';

export interface BookingModel {
  id: number;
  roomId: number;
  checkInDate: string;
  checkOutDate: string;
  adults: number;
  children: number;
  status: string;
}

export interface BookingRequest {
  roomId: number | null;
  checkInDate: string;
  checkOutDate: string;
  adults: number;
  children: number;
  status: string;
}

@Injectable({ providedIn: 'root' })
export class BookingService {
  constructor(private http: HttpClient) {}

  private getAuthHeaders(): HttpHeaders {
    const token = localStorage.getItem('token') || '';
    return new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`
    });
  }

  myBookings(): Observable<BookingModel[]> {
    return this.http.get<BookingModel[]>(API, { headers: this.getAuthHeaders() });
  }

  bookRoom(payload: BookingRequest): Observable<BookingModel> {
    return this.http.post<BookingModel>(API, payload, { headers: this.getAuthHeaders() });
  }

  cancel(id: number): Observable<void> {
    return this.http.delete<void>(`${API}/${id}`, { headers: this.getAuthHeaders() });
  }
}
