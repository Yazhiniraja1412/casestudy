import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService, SignupPayload } from '../auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  templateUrl: './register.html',
  styleUrls: ['./register.css'],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule
  ]
})
export class Register {

  registerForm: FormGroup;
  error   = '';
  success = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.registerForm = this.fb.group({
      username: ['', Validators.required],
      email:    ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      roles:    this.fb.group({
        USER:      [true],   // default role
        ADMIN:     [false],
        OWNER:     [false]
      })
    });
  }

  /* ----------  👉  UPDATED METHOD  ---------- */
  onSubmit(): void {
    if (this.registerForm.invalid) return;

    // Safe extraction of the nested roles group
    const rolesGroup = this.registerForm.get('roles')?.value as { [key: string]: boolean };
    const chosenRoles = Object.keys(rolesGroup).filter(r => rolesGroup[r]);

    const payload: SignupPayload = {
      username: this.registerForm.value.username,
      email:    this.registerForm.value.email,
      password: this.registerForm.value.password,
      roles:    chosenRoles
    };

    this.authService.register(payload).subscribe({
  next: msg => {                        // msg is "User registered successfully!"
    this.success = msg;                 // show it in the template
    setTimeout(() => this.router.navigate(['/login']), 1500);
  },
  error: err => {
    this.error = 'Registration failed';
    console.error(err);
  }
});
this.registerForm = this.fb.group({
  username: ['', Validators.required],
  email: ['', [Validators.required, Validators.email]],
  password: ['', [Validators.required, Validators.minLength(6)]],
  roles: this.fb.group({
    USER: [true],
    ADMIN: [false],
    OWNER: [false]
  })
});


  }
}
