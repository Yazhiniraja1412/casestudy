import { Component, OnInit, inject } from '@angular/core';
import { FormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BookingModel, BookingRequest, BookingService } from '../booking.service';

@Component({
  selector: 'app-booking',
  standalone: true,
  templateUrl: './booking.html',
  styleUrls: ['./booking.css'],
  imports: [CommonModule, ReactiveFormsModule, RouterModule]
})
export class Booking implements OnInit {

  private fb = inject(FormBuilder);
  private api = inject(BookingService);

  bookings: BookingModel[] = [];
  error = '';
  success = '';

  bookingForm = this.fb.group({
    roomId:        [null, Validators.required],
    checkInDate:   ['', Validators.required],
    checkOutDate:  ['', Validators.required],
    adults:        [1, [Validators.required, Validators.min(1), Validators.max(2)]],
    children:      [0]
  });

  ngOnInit() {
    this.refresh();
  }

  refresh() {
    this.api.myBookings().subscribe({
      next: list => {
        console.log("✅ My Bookings from API:", list);
        this.bookings = list;
      },
      error: () => this.error = 'Could not load bookings'
    });
  }

  submit() {
    if (this.bookingForm.invalid) {
      this.bookingForm.markAllAsTouched();
      return;
    }

    const formVal = this.bookingForm.value;

    const payload: BookingRequest = {
      roomId: Number(formVal.roomId), // ✅ this is correct now
      checkInDate: formVal.checkInDate || '',
      checkOutDate: formVal.checkOutDate || '',
      adults: formVal.adults ?? 1,
      children: formVal.children ?? 0,
      status: 'ACTIVE'
    };

    this.api.bookRoom(payload).subscribe({
      next: () => {
        this.success = 'Booked!';
        this.error = '';
        this.bookingForm.reset({
          roomId: null,
          checkInDate: '',
          checkOutDate: '',
          adults: 1,
          children: 0
        });
        this.refresh();
      },
      error: () => {
        this.success = '';
        this.error = 'Booking failed';
      }
    });
  }

  cancel(id: number) {
    const confirmed = window.confirm('Are you sure you want to cancel this booking?');
    if (!confirmed) return;

    this.api.cancel(id).subscribe({
      next: () => {
        this.success = 'Booking cancelled';
        this.refresh();
      },
      error: () => {
        this.error = 'Cancel failed';
        this.success = '';
      }
    });
  }
}
