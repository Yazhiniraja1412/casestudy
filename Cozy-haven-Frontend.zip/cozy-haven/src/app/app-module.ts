import { NgModule }            from '@angular/core';
import { BrowserModule }       from '@angular/platform-browser';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule }        from '@angular/router';
import { CommonModule }        from '@angular/common';

import { AppRoutingModule } from './app-routing-module';
import { App }             from './app';

/* classic (declared) components */
import { Home } from './home/home';

/* stand‑alone components */
import { Login }      from './login/login';
import { Register }   from './register/register';
import { Dashboard }  from './dashboard/dashboard';
import { Booking }    from './booking/booking';
import { Hotel }      from './hotel/hotel';
import { HotelList }  from './hotel-list/hotel-list';
import { RoomList }   from './room-list/room-list';
import { Review }     from './review/review';

/* interceptor */
import { AuthInterceptor } from './auth-interceptor.service';
import { About } from './about/about';

@NgModule({
  declarations: [
    App,
    Home,
    About                // only non‑stand‑alone comps here
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule,
    AppRoutingModule,
    CommonModule,

    /* stand‑alone comps */
    Login,
    Register,
    Dashboard,
    Booking,
    Hotel,
    HotelList,
    RoomList,
    Review
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }
  ],
  bootstrap: [App]
})
export class AppModule { }
