import { Component, OnInit, inject } from '@angular/core';
import { CommonModule }      from '@angular/common';
import { RouterModule }      from '@angular/router';
import { HotelService, HotelModel } from '../hotel.service';
import { RoomService,  RoomModel  } from '../room.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-hotel-list',
  standalone: true,
  templateUrl: './hotel-list.html',
  styleUrls:  ['./hotel-list.css'],
  imports:    [CommonModule, RouterModule,FormsModule]
})
export class HotelList implements OnInit {

  /* ------------------------------------------------------------------ */
  /*  Services                                                          */
  /* ------------------------------------------------------------------ */
  private hotelApi = inject(HotelService);
  private roomApi  = inject(RoomService);

  /* ------------------------------------------------------------------ */
  /*  View‑state                                                         */
  /* ------------------------------------------------------------------ */
  hotels: HotelModel[] = [];
  error  = '';

  /** map hotelId → rooms[] (for inline toggle) */
  roomCache: Record<number, RoomModel[]> = {};
  loadingRooms: number | null = null;

  /** 🔸 map hotelId → base64 preview or external URL (localStorage) */
  imageMap: Record<number, string> = {};

  /** whether current user is allowed to change photos */
  isOwner = true;   // swap with real auth check later

  /* ------------------------------------------------------------------ */
  /*  Lifecycle                                                         */
  /* ------------------------------------------------------------------ */
  ngOnInit(): void {
    /* hydrate thumbnails saved in previous sessions */
    const saved = localStorage.getItem('hotelImages');
    if (saved) this.imageMap = JSON.parse(saved);

    /* load hotel list from backend */
    this.hotelApi.list().subscribe({
      next: list => (this.hotels = list),
      error: ()   => (this.error  = 'Could not load hotels')
    });
  }

  /* ------------------------------------------------------------------ */
  /*  Rooms inline toggle                                               */
  /* ------------------------------------------------------------------ */
  toggleRooms(h: HotelModel) {
    if (this.roomCache[h.id]) { delete this.roomCache[h.id]; return; }

    this.loadingRooms = h.id;
    this.roomApi.listByHotel(h.id).subscribe({
      next: list => { this.roomCache[h.id] = list; this.loadingRooms = null; },
      error: ()   => { this.error = 'Could not load rooms'; this.loadingRooms = null; }
    });
  }

  /* ------------------------------------------------------------------ */
  /*  Owner picks / changes photo                                       */
  /* ------------------------------------------------------------------ */
  pickPhoto(evt: Event, hotelId: number) {
    const file = (evt.target as HTMLInputElement).files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      /* save base64 string locally and persist */
      this.imageMap[hotelId] = reader.result as string;
      localStorage.setItem('hotelImages', JSON.stringify(this.imageMap));
    };
    reader.readAsDataURL(file);
  }

  
  getThumb(id: number, fallback: string): string {
  return localStorage.getItem(`hotel-img-${id}`) || fallback;
}

}
