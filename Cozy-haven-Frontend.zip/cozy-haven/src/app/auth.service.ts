import { HttpClient } from '@angular/common/http';
import { Injectable }  from '@angular/core';
import { Observable, tap } from 'rxjs';

/* ---------- DTOs ---------- */
export interface SignupPayload {
  username: string;
  email:    string;
  password: string;
  roles:    string[];               // e.g. ['OWNER'] or ['USER']
}

export interface LoginPayload {
  username: string;
  password: string;
}

/* ---------- Auth Service (original) ---------- */
@Injectable({ providedIn: 'root' })
export class AuthService {

  private readonly API = 'http://localhost:9090/api/auth';

  constructor(private http: HttpClient) {}

  /* register */
  register(payload: SignupPayload) {
    return this.http.post(
      `${this.API}/register`,        // ✅ back‑ticks
      payload,
      { responseType: 'text' }
    );
  }

  /* login */
  login(payload: LoginPayload): Observable<{ token: string }> {
    return this.http
      .post<{ token: string }>(
        `${this.API}/login`,         // ✅ back‑ticks
        payload
      )
      .pipe(
        tap(res => localStorage.setItem('jwt', res.token))   // save token
      );
  }

  /* logout */
 logout(): void {
  ['jwt', 'token', 'roles'].forEach(k => localStorage.removeItem(k));
}
  /* token helper */
  get token(): string | null {
    return localStorage.getItem('jwt');
  }

  /* decode roles (kept intact) */
  private rolesFromToken(): string[] {
    if (!this.token) return [];
    try {
      const [, payload] = this.token.split('.');
      return JSON.parse(atob(payload)).roles || [];
    } catch {
      return [];
    }
  }

  /* first role or USER fallback */
  role(): string {
    const roles = this.rolesFromToken();
    return roles.length ? roles[0] : 'USER';
  }

  /* legacy flag */
  get canManageHotels(): boolean {
    return this.rolesFromToken().some(r => r === 'OWNER' || r === 'ADMIN');
  }
  
}
