package com.cozyhaven.controller;

import com.cozyhaven.dto.BookingRequest;
import com.cozyhaven.dto.BookingResponse;
import com.cozyhaven.entity.User;
import com.cozyhaven.entity.Booking;
import com.cozyhaven.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin(origins = "http://localhost:4200")
public class BookingController {

    @Autowired private BookingService bookingService;

    @PostMapping
    public ResponseEntity<Booking> book(@RequestBody BookingRequest req, Authentication auth) {
        Booking booking = bookingService.bookRoom(
                ((com.cozyhaven.entity.User) auth.getPrincipal()).getId(),
                req.roomId(),
                req.checkInDate(),
                req.checkOutDate(),
                req.adults(),
                req.children()
        );
        return ResponseEntity.ok(booking);
    }

    @GetMapping
    public ResponseEntity<List<BookingResponse>> myBookings(Authentication auth) {
        Long userId = ((User) auth.getPrincipal()).getId();

        List<BookingResponse> response = bookingService.getUserBookings(userId)
            .stream()
            .map(b -> new BookingResponse(
                b.getId(),
                b.getRoom().getId(),  
                b.getCheckInDate(),
                b.getCheckOutDate(),
                b.getAdults(),
                b.getChildren(),
                b.getStatus().toString()
            ))
            .toList();

        return ResponseEntity.ok(response);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<?> cancel(@PathVariable Long id) {
        System.out.println("Cancel request received for booking ID: " + id);
        try {
            bookingService.cancelBooking(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            System.err.println("Cancel failed: " + e.getMessage());
            return ResponseEntity.badRequest().body("Could not cancel booking. Reason: " + e.getMessage());
        }
    }

}
