// src/main/java/com/cozyhaven/repository/HotelRepository.java
package com.cozyhaven.repository;

import com.cozyhaven.entity.Hotel;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface HotelRepository extends JpaRepository<Hotel, Long> {

    // optional: eager fetch of rooms
    @Query("SELECT h FROM Hotel h LEFT JOIN FETCH h.rooms")
    List<Hotel> findAllWithRooms();
}
