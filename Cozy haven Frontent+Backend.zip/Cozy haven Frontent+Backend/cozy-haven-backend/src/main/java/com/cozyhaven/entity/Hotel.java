package com.cozyhaven.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Hotel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String location;
    private String description;
    private String amenities;

    @OneToMany(mappedBy = "hotel",
               cascade = CascadeType.ALL,
               orphanRemoval = true)
    @JsonManagedReference          // ✅ prevents infinite loop
    private List<Room> rooms = new ArrayList<>();
}
