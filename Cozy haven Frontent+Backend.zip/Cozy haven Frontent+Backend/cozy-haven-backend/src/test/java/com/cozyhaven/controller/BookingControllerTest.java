package com.cozyhaven.controller;

import com.cozyhaven.entity.Booking;
import com.cozyhaven.entity.Role;
import com.cozyhaven.entity.Room;
import com.cozyhaven.entity.User;
import com.cozyhaven.entity.Booking.Status;
import com.cozyhaven.exception.ResourceNotFoundException;
import com.cozyhaven.repository.BookingRepository;
import com.cozyhaven.repository.RoomRepository;
import com.cozyhaven.repository.UserRepository;
import com.cozyhaven.service.BookingService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.time.LocalDate;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class BookingControllerTest {

    @InjectMocks
    private BookingService bookingService;

    @Mock private BookingRepository bookingRepo;
    @Mock private RoomRepository roomRepo;
    @Mock private UserRepository userRepo;

    private User testUser;
    private Room testRoom;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        testUser = User.builder()
                .id(1L)
                .username("john")
                .email("john@example.com")
                .roles(Set.of(Role.ROLE_USER))
                .build();

        testRoom = Room.builder()
                .id(2L)
                .available(true)
                .baseFare(1000.0)
                .maxOccupancy(4)
                .build();
    }

    @Test
    void bookRoom_successful() {
        LocalDate checkIn = LocalDate.of(2025, 7, 15);
        LocalDate checkOut = LocalDate.of(2025, 7, 17);

        when(userRepo.findById(1L)).thenReturn(Optional.of(testUser));
        when(roomRepo.findById(2L)).thenReturn(Optional.of(testRoom));
        when(bookingRepo.save(any(Booking.class)))
                .thenAnswer(invocation -> {
                    Booking booking = invocation.getArgument(0);
                    booking.setId(99L);
                    return booking;
                });

        Booking result = bookingService.bookRoom(1L, 2L, checkIn, checkOut, 2, 0);

        assertNotNull(result);
        assertEquals(99L, result.getId());
        assertEquals(testUser, result.getUser());
        assertEquals(testRoom, result.getRoom());
        assertEquals(Status.BOOKED, result.getStatus());
        verify(bookingRepo).save(any(Booking.class));
    }

    @Test
    void cancelBooking_updatesStatus() {
        Room room = Room.builder().id(2L).available(false).build();

        Booking booking = Booking.builder()
                .id(123L)
                .status(Status.BOOKED)
                .room(room)
                .build();

        when(bookingRepo.findById(123L)).thenReturn(Optional.of(booking));
        when(bookingRepo.save(any(Booking.class))).thenReturn(booking); // ✅ Needed for verification

        bookingService.cancelBooking(123L);

        assertEquals(Status.CANCELLED, booking.getStatus());
        assertTrue(booking.getRoom().isAvailable());
        verify(bookingRepo).save(booking); // ✅ Assertion passed only if save() is called
    }

    @Test
    void cancelBooking_notFound() {
        when(bookingRepo.findById(999L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> bookingService.cancelBooking(999L));
    }
}
