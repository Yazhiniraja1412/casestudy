package com.cozyhaven.controller;

import com.cozyhaven.controller.HotelController;
import com.cozyhaven.entity.Hotel;
import com.cozyhaven.entity.Role;
import com.cozyhaven.entity.User;
import com.cozyhaven.service.HotelService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class HotelControllerTest {

    @InjectMocks
    private HotelController hotelController;

    @Mock
    private HotelService hotelService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Simulate authenticated user in context (OWNER or ADMIN)
        User mockUser = User.builder()
                .id(1L)
                .username("admin")
                .email("admin@example.com")
                .password("admin123")
                .roles(Set.of(Role.ROLE_ADMIN))
                .build();

        var auth = new UsernamePasswordAuthenticationToken(mockUser, null, mockUser.getAuthorities());
        SecurityContext context = SecurityContextHolder.createEmptyContext();
        context.setAuthentication(auth);
        SecurityContextHolder.setContext(context);
    }

    @Test
    void testListAllHotels() {
        Hotel h1 = Hotel.builder().id(1L).name("Cozy").location("Goa").build();
        when(hotelService.findAll()).thenReturn(List.of(h1));

        ResponseEntity<List<Hotel>> response = hotelController.list();

        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().size());
        assertEquals("Cozy", response.getBody().get(0).getName());

        verify(hotelService).findAll();
    }

    @Test
    void testGetHotelById() {
        Hotel hotel = Hotel.builder().id(2L).name("Haven").location("Delhi").build();
        when(hotelService.findById(2L)).thenReturn(hotel);

        ResponseEntity<Hotel> response = hotelController.get(2L);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Haven", response.getBody().getName());

        verify(hotelService).findById(2L);
    }

    @Test
    void testAddHotel() {
        Hotel input = Hotel.builder().name("New").location("Chennai").build();
        Hotel saved = Hotel.builder().id(3L).name("New").location("Chennai").build();
        when(hotelService.saveHotel(any(Hotel.class))).thenReturn(saved);

        ResponseEntity<Hotel> response = hotelController.add(input);

        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertEquals(3L, response.getBody().getId());
        assertEquals("New", response.getBody().getName());

        verify(hotelService).saveHotel(any(Hotel.class));
    }

    @Test
    void testDeleteHotel() {
        doNothing().when(hotelService).delete(4L);

        ResponseEntity<Void> response = hotelController.delete(4L);

        assertEquals(204, response.getStatusCodeValue()); // No Content
        assertNull(response.getBody());

        verify(hotelService).delete(4L);
    }
}
