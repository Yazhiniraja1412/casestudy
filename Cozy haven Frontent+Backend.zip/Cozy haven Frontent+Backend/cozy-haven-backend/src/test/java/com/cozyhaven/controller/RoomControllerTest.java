package com.cozyhaven.controller;

import com.cozyhaven.entity.Room;
import com.cozyhaven.service.RoomService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import org.springframework.http.ResponseEntity;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class RoomControllerTest {

    @InjectMocks
    private RoomController roomController;

    @Mock
    private RoomService roomService;

    @BeforeEach
    void init() {
        MockitoAnnotations.openMocks(this);
    }

    /* ---------- GET /api/rooms?hotelId= -------------------- */
    @Test
    void testListRoomsByHotel() {
        Long hotelId = 4L;

        Room room = Room.builder()
                .id(1L)
                .roomSize("Deluxe")
                .bedType("Double")
                .baseFare(4000)
                .ac(true)
                .available(true)
                .build();

        when(roomService.findByHotelId(hotelId)).thenReturn(List.of(room));

        ResponseEntity<List<Room>> response = roomController.listByHotel(hotelId);

        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().size());
        assertEquals("Deluxe", response.getBody().get(0).getRoomSize());

        verify(roomService).findByHotelId(hotelId);
    }

    /* ---------- GET /api/rooms/{id} ------------------------ */
    @Test
    void testGetRoomById() {
        Room room = Room.builder()
                .id(2L)
                .roomSize("Std")
                .bedType("Single")
                .baseFare(2500)
                .ac(true)
                .available(true)
                .build();

        when(roomService.findById(2L)).thenReturn(room);

        ResponseEntity<Room> response = roomController.get(2L);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(2L, response.getBody().getId());
        assertEquals("Single", response.getBody().getBedType());

        verify(roomService).findById(2L);
    }

    /* ---------- POST /api/rooms ---------------------------- */
    @Test
    void testAddRoom() {
        Room requestRoom = Room.builder()
                .roomSize("Luxury")
                .bedType("King")
                .baseFare(5000)
                .ac(true)
                .available(true)
                .build();

        Room savedRoom = Room.builder()
                .id(3L)
                .roomSize("Luxury")
                .bedType("King")
                .baseFare(5000)
                .ac(true)
                .available(true)
                .build();

        when(roomService.saveRoom(requestRoom, 1L)).thenReturn(savedRoom);

        ResponseEntity<Room> response = roomController.add(requestRoom, 1L);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(3L, response.getBody().getId());
        assertEquals("Luxury", response.getBody().getRoomSize());

        verify(roomService).saveRoom(requestRoom, 1L);
    }

    /* ---------- DELETE /api/rooms/{id} --------------------- */
    @Test
    void testDeleteRoom() {
        Long roomId = 5L;

        doNothing().when(roomService).delete(roomId);

        ResponseEntity<Void> response = roomController.delete(roomId);

        assertEquals(204, response.getStatusCodeValue());
        assertNull(response.getBody());

        verify(roomService).delete(roomId);
    }
}
