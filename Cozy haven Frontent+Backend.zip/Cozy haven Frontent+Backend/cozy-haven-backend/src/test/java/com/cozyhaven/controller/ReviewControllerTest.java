package com.cozyhaven.controller;

import com.cozyhaven.entity.Review;
import com.cozyhaven.entity.Role;
import com.cozyhaven.entity.User;
import com.cozyhaven.service.ReviewService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;

import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ReviewControllerTest {

    @InjectMocks
    private ReviewController reviewController;

    @Mock
    private ReviewService reviewService;

    private Authentication authentication;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Simulated authenticated user (john with ROLE_USER)
        User mockUser = User.builder()
                .id(1L)
                .username("john")
                .email("john@example.com")
                .password("secret")
                .roles(Set.of(Role.ROLE_USER))
                .build();

        authentication = new UsernamePasswordAuthenticationToken(
                mockUser, null, mockUser.getAuthorities()
        );
    }

    @Test
    void testAddReview() {
        Long hotelId = 4L;
        int rating = 5;
        String comment = "Great stay!";

        Review mockReview = Review.builder()
                .id(10L)
                .rating(rating)
                .comment(comment)
                .build();

        when(reviewService.addReview(1L, hotelId, rating, comment)).thenReturn(mockReview);

        ResponseEntity<Review> response = reviewController.add(hotelId, rating, comment, authentication);

        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertEquals(10L, response.getBody().getId());
        assertEquals("Great stay!", response.getBody().getComment());

        verify(reviewService).addReview(1L, hotelId, rating, comment);
    }

    @Test
    void testListReviews() {
        Long hotelId = 4L;
        Review r1 = Review.builder().id(100L).rating(4).comment("Nice").build();
        when(reviewService.listReviews(hotelId)).thenReturn(List.of(r1));

        ResponseEntity<List<Review>> response = reviewController.list(hotelId);

        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertEquals(1, response.getBody().size());
        assertEquals(100L, response.getBody().get(0).getId());

        verify(reviewService).listReviews(hotelId);
    }

    @Test
    void testListAllReviews() {
        Review r1 = Review.builder().id(1L).rating(3).comment("Ok").build();
        Review r2 = Review.builder().id(2L).rating(5).comment("Perfect!").build();

        when(reviewService.listAll()).thenReturn(List.of(r1, r2));

        ResponseEntity<List<Review>> response = reviewController.listAll();

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(2, response.getBody().size());
        assertEquals("Ok", response.getBody().get(0).getComment());

        verify(reviewService).listAll();
    }
}
