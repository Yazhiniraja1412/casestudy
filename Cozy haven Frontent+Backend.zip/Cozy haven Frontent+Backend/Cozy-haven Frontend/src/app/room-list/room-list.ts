import { Component, OnInit, inject } from '@angular/core';
import { CommonModule }              from '@angular/common';
import { ActivatedRoute, RouterModule } from '@angular/router';
import { HttpClient, HttpHeaders }   from '@angular/common/http';
import { Observable }                from 'rxjs';

/* -------- data model -------- */
export interface RoomModel {
  id?: number;
  roomSize: string;
  bedType: string;
  baseFare: number;
  maxOccupancyBase: number;
  maxOccupancy: number;
  ac: boolean;
  available: boolean;
}


/* -------- component -------- */
@Component({
  selector: 'app-room-list',
  standalone: true,
  templateUrl: './room-list.html',
  styleUrls: ['./room-list.css'],
  imports: [CommonModule, RouterModule]
})
export class RoomList implements OnInit {

  private http  = inject(HttpClient);
  private route = inject(ActivatedRoute);

  hotelId!: number;
  rooms: RoomModel[] = [];
  error = '';

  ngOnInit(): void {
    this.hotelId = Number(this.route.snapshot.paramMap.get('hotelId'));

    this.fetchRooms(this.hotelId).subscribe({
      next: list => (this.rooms = list),
      error: ()   => (this.error = 'Could not load rooms (403?)')
    });
  }

  /* -------- helper -------- */
  fetchRooms(id: number): Observable<RoomModel[]> {
    const token  = localStorage.getItem('token') || '';
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);

    return this.http.get<RoomModel[]>(
      `http://localhost:9090/api/rooms?hotelId=${id}`,
      { headers }
    );
  }
}
