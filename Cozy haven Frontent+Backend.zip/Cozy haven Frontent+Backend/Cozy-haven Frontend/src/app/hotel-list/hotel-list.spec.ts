// src/app/hotel/hotel-list.spec.ts
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule }   from '@angular/common/http/testing';

import { HotelList } from './hotel-list';   // ✅ correct class name

describe('HotelList ', () => {
  let component: HotelList;
  let fixture: ComponentFixture<HotelList>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      // stand‑alone components go in imports
      imports: [
        HotelList,
        HttpClientTestingModule   // mocks HttpClient for HotelService
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(HotelList);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
