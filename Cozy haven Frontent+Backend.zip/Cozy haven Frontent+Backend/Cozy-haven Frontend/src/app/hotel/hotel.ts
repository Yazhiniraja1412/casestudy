import { Component, OnInit, inject } from '@angular/core';
import { CommonModule }              from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { RouterModule }              from '@angular/router';

import { HotelService, HotelModel, HotelDTO } from '../hotel.service';
import { RoomService,  RoomModel }            from '../room.service';
import { AuthService }                        from '../auth.service';   // <-- add

@Component({
  selector:    'app-hotel',
  standalone:  true,
  templateUrl: './hotel.html',
  styleUrls:   ['./hotel.css'],
  imports: [CommonModule, ReactiveFormsModule, RouterModule]
})
export class Hotel implements OnInit {

  /* ───────── DI shortcuts ───────── */
  private fb        = inject(FormBuilder);
  private hotelApi  = inject(HotelService);
  private roomApi   = inject(RoomService);
  private auth      = inject(AuthService);

  /* ───────── component state ───────── */
  hotels:   HotelModel[]            = [];
  imageMap: Record<number,string>   = {};   // hotelId → base‑64 url
  msgHotel = '';   // success message when adding hotel
  msgRoom  = '';   // success message when adding room
  err      = '';   // general error string

  /* ───────── Add‑Hotel form ───────── */
  hotelForm = this.fb.nonNullable.group({
    name:        ['', Validators.required],
    location:    ['', Validators.required],
    description: ['', Validators.required],
    amenities:   ['', Validators.required]
  });

  /* ───────── Add‑Room form ───────── */
  roomForm = this.fb.nonNullable.group({
    hotelId:          0,
    roomSize:         '',
    bedType:          '',
    baseFare:         0,
    maxOccupancyBase: 2,
    maxOccupancy:     2,
    ac:               true,
    available:        true
  });

  /* ───────── life‑cycle ───────── */
  ngOnInit(): void { this.reloadHotels(); }

  /* ───────── reload list & thumbnails ───────── */
  private reloadHotels(): void {
    this.hotelApi.list().subscribe({
      next: list => {
        this.hotels = list;
        this.buildImageMap(list);
      },
      error: ()   => this.err = '❌ Could not load hotels'
    });
  }

  /** create imageMap from localStorage or existing h.image */
  private buildImageMap(list: HotelModel[]): void {
    this.imageMap = {};
    for (const h of list) {
      const stored = localStorage.getItem(`hotel-img-${h.id}`);
      this.imageMap[h.id] = stored || h.image || '';
    }
  }

  /* ───────── save hotel ───────── */
  saveHotel(): void {
    if (this.hotelForm.invalid) return;
    const dto: HotelDTO = this.hotelForm.getRawValue();

    this.hotelApi.add(dto).subscribe({
      next: () => {
        this.msgHotel = '✅ Hotel added!';
        this.hotelForm.reset();
        this.reloadHotels();
      },
      error: () => this.err = '❌ Failed to add hotel'
    });
  }

  /* ───────── save room ───────── */
  saveRoom(): void {
    if (this.roomForm.invalid) return;

    const raw = this.roomForm.getRawValue();
    const roomDto: RoomModel = {
      roomSize:         raw.roomSize,
      bedType:          raw.bedType,
      baseFare:         raw.baseFare,
      maxOccupancyBase: raw.maxOccupancyBase,
      maxOccupancy:     raw.maxOccupancy,
      ac:               raw.ac,
      available:        raw.available
    };

    this.roomApi.addRoom(raw.hotelId, roomDto).subscribe({
      next: () => {
        this.msgRoom = `Room added to hotel #${raw.hotelId} ✔`;
        this.roomForm.reset({
          hotelId: raw.hotelId,
          roomSize:'', bedType:'',
          baseFare:0, maxOccupancyBase:2, maxOccupancy:2,
          ac:true, available:true
        });
      },
      error: () => this.err = '❌ Add room failed'
    });
  }

  /* ───────── delete hotel ───────── */
  delete(id: number): void {
    this.hotelApi.delete(id).subscribe({
      next: () => {
        localStorage.removeItem(`hotel-img-${id}`); // purge thumbnail
        this.reloadHotels();
      },
      error: () => this.err = '❌ Delete failed (check role)'
    });
  }

  /* ───────── upload / change photo ───────── */
  /* ───────── upload / change photo ───────── */
uploadPhoto(e: Event, hotelId: number): void {
  /* TEMP: bypass the role check for your demo */
  // if (!this.auth.canManageHotels) return;

  const file = (e.target as HTMLInputElement).files?.[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = () => {
    const base64 = reader.result as string;
    this.imageMap[hotelId] = base64;                     // update preview
    localStorage.setItem(`hotel-img-${hotelId}`, base64); // persist
  };
  reader.readAsDataURL(file);
}

}
