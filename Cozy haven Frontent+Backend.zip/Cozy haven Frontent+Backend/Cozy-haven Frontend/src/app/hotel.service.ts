import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

const API = 'http://localhost:9090/api/hotels';

/* ---------- Data models ---------- */
export interface HotelModel {
  id: number;
  name: string;
  location: string;
  description: string;
  amenities: string;
  image?: string;
}

export type HotelDTO = Omit<HotelModel, 'id'>;   // ✔ just the hotel fields

@Injectable({ providedIn: 'root' })
export class HotelService {

  constructor(private http: HttpClient) {}

  private headers() {
    return { headers: new HttpHeaders({
      Authorization: `Bearer ${localStorage.getItem('token') || ''}`
    })};
  }

  list(): Observable<HotelModel[]> {
    return this.http.get<HotelModel[]>(API, this.headers());
  }

  add(hotel: HotelDTO): Observable<HotelModel> {
    return this.http.post<HotelModel>(API, hotel, this.headers());
  }

  delete(id: number) {
    return this.http.delete(`${API}/${id}`, this.headers());
  }
}
