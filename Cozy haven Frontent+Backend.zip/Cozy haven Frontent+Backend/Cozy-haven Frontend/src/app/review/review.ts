import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  ReactiveFormsModule, FormBuilder, Validators
} from '@angular/forms';
import { ReviewService, ReviewModel } from '../review.service';
import { RouterModule } from '@angular/router';

@Component({
  standalone: true,
  selector: 'app-review',
  templateUrl: './review.html',
  styleUrls: ['./review.css'],
  imports: [CommonModule, ReactiveFormsModule,RouterModule]
})
export class Review implements OnInit {

  reviews: ReviewModel[] = [];
  ratings = [1, 2, 3, 4, 5];

  private fb  = inject(FormBuilder);
  private api = inject(ReviewService);

  /** nonNullable -> no boolean|null issues */
  form = this.fb.nonNullable.group({
    hotelId: 0,
    rating:  5,
    comment: ['', Validators.required]
  });

  /* ------------ load every review on first render ------------ */
  ngOnInit(): void {
    this.api.listAll().subscribe(r => (this.reviews = r));
  }

  submit(): void {
    if (this.form.invalid) return;

    const { hotelId, rating, comment } = this.form.getRawValue();

    this.api.addReview(hotelId, rating, comment).subscribe(newRev => {
      this.reviews.unshift(newRev);          // show instantly
      this.form.reset({ hotelId, rating: 5, comment: '' });
    });
  }
}
