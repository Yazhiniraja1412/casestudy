// src/app/core/token-store.service.ts
import { Injectable } from '@angular/core';

const KEY = 'token';                       // <- localStorage key

@Injectable({ providedIn: 'root' })
export class TokenStore {
  set(token: string): void   { localStorage.setItem(KEY, token); }
  get(): string | null       { return localStorage.getItem(KEY); }
  clear(): void              { localStorage.removeItem(KEY);     }
}
