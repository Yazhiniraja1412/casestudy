import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../auth.service';
import { Router }    from '@angular/router';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.css'],
  imports: [RouterModule, CommonModule]   // for routerLink, ngClass, etc.
})
export class Dashboard {  
  constructor(
    private  auth: AuthService,
    private router: Router          // ← then inject it
  ) {}
  

   showPhone: boolean = false;
  

  // 👇 This method toggles it on/off
  togglePhone(): void {
    this.showPhone = !this.showPhone;
  }
  
confirmLogout(): void {
    if (confirm('Are you sure you want to log out?')) {
      this.auth.logout();
      this.router.navigate(['/login']);   // redirect to login page
    }
  }



  /* no role logic — card always shown */ }
