import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

const API = 'http://localhost:9090/api/rooms';

// after RoomModel
export interface RoomModel {
  id?: number;               // optional for POST
  roomSize: string;
  bedType: string;
  baseFare: number;
  maxOccupancyBase: number;
  maxOccupancy: number;
  ac: boolean;
  available: boolean;
}

@Injectable({ providedIn: 'root' })
export class RoomService {

  constructor(private http: HttpClient) {}

  private headers() {
    return { headers: new HttpHeaders({
      Authorization: `Bearer ${localStorage.getItem('token') || ''}`
    })};
  }

  /** POST /api/rooms?hotelId=3 */
  addRoom(hotelId: number, dto: RoomModel): Observable<RoomModel> {
    const params = new HttpParams().set('hotelId', hotelId.toString());   // 👈 cast to string
    return this.http.post<RoomModel>(API, dto, { ...this.headers(), params });
  }

  /** GET /api/rooms?hotelId=3 */
  listByHotel(hotelId: number): Observable<RoomModel[]> {
    const params = new HttpParams().set('hotelId', hotelId.toString());   // 👈 cast to string
    return this.http.get<RoomModel[]>(API, { ...this.headers(), params });
  }
}
