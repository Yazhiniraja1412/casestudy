// src/app/app-routing-module.ts
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { Login }      from './login/login';
import { Register }   from './register/register';
import { Dashboard }  from './dashboard/dashboard';
import { Booking }    from './booking/booking';     // ⬅ stand‑alone
import { Hotel } from './hotel/hotel';
import { HotelList } from './hotel-list/hotel-list';
import { RoomList } from './room-list/room-list';
import { Review } from "./review/review";
import { AuthGuard } from './auth.guard';
import { Home } from './home/home';
import { About } from "./about/about";

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },

  /* public */
  { path: 'login',    component: Login },
  { path: 'register', component: Register },
  { path: 'about', component: About },

  /* guarded */
  { path: 'dashboard',     component: Dashboard, canActivate: [AuthGuard] },
  { path: 'bookings',      component: Booking,   canActivate: [AuthGuard] },
  { path: 'hotel-control',  component: Hotel,
    canActivate: [AuthGuard] },

  /* public hotel browsing */
  { path: 'hotels', component: HotelList , canActivate: [AuthGuard]},
  { path: 'hotels/:hotelId/rooms',   component: RoomList , canActivate: [AuthGuard]},
  { path: 'reviews', component: Review , canActivate: [AuthGuard] },
  

  /* wildcard LAST */
  { path: '**', redirectTo: '' },
  { path: '', component: Home }
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
