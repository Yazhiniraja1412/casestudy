package com.cozyhaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest           // launches the full application context
class CozyHavenApplicationTest {

    @Test
    void contextLoads() {
        // no-op: test passes if the context starts successfully
    }
}
