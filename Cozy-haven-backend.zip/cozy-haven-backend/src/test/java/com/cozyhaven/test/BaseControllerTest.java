package com.cozyhaven.test;

import com.cozyhaven.config.JwtUtils;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

/**
 * Bootstraps MVC with EVERY controller, but mocks anything
 * outside the web layer so tests run fast and never complain
 * about missing beans or JWT secrets.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc(addFilters = false)   // 🔑 bypass Spring‑Security chain
@ActiveProfiles("test")                     // in case you use profile‑based config
@TestPropertySource(properties = {
        // minimal JWT props so real JwtUtils won't blow up (if instantiated)
        "jwt.secret=dGhpcy1pcy1qd3Qtc2VjcmV0LTI1Ni1iaXRzLWxvbmc=",
        "jwt.expiration=PT1H"
})
// Exclude the REAL JwtUtils so our @MockBean below wins
@ComponentScan(
        excludeFilters = @ComponentScan.Filter(
                type = FilterType.ASSIGNABLE_TYPE,
                classes = JwtUtils.class
        )
)
@ExtendWith(MockitoExtension.class)
public abstract class BaseControllerTest {

    /**
     * Mockito stub replaces the real JwtUtils for EVERY test that extends
     * this base class, so you never get IllegalStateException about keys.
     */
    @MockBean
    protected JwtUtils jwtUtils;
}
