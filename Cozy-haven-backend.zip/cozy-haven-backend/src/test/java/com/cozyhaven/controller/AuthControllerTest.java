package com.cozyhaven.controller;

import com.cozyhaven.dto.JwtResponse;
import com.cozyhaven.dto.LoginRequest;
import com.cozyhaven.dto.SignupRequest;
import com.cozyhaven.entity.Role;
import com.cozyhaven.entity.User;
import com.cozyhaven.service.AuthService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AuthControllerTest {

    @InjectMocks
    private AuthController authController;

    @Mock
    private AuthService authService;

    @BeforeEach
    void setup() {
        MockitoAnnotations.openMocks(this);

        // Simulate authenticated user (optional)
        User mockUser = User.builder()
                .id(1L)
                .username("john")
                .email("john@example.com")
                .password("x")
                .roles(Set.of(Role.ROLE_USER))
                .build();

        Authentication authentication = mock(Authentication.class);
        when(authentication.getPrincipal()).thenReturn(mockUser);

        SecurityContext context = SecurityContextHolder.createEmptyContext();
        context.setAuthentication(authentication);
        SecurityContextHolder.setContext(context);
    }

    @Test
    void testRegister() {
        // Arrange
        SignupRequest signup = new SignupRequest(
            "john",
            "john@example.com",
            "Secret123!",
            Set.of("USER")
        );

        doNothing().when(authService).register(any(SignupRequest.class));

        // Act
        ResponseEntity<?> response = authController.register(signup);

        // Assert
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("User registered successfully!", response.getBody());
        verify(authService).register(any(SignupRequest.class));
    }

    @Test
    void testLogin() {
        // Arrange
        LoginRequest loginRequest = new LoginRequest("john@example.com", "Secret123!");

        JwtResponse jwt = new JwtResponse(
            "dummy-token",         // token
            "Bearer",              // type
            1L,                    // id
            "john",                // username
            "john@example.com",    // email
            Set.of("ROLE_USER")    // roles as Strings, not enums
        );

        when(authService.login(any(LoginRequest.class))).thenReturn(jwt);

        // Act
        ResponseEntity<JwtResponse> response = authController.login(loginRequest);

        // Assert
        assertEquals(200, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertEquals("dummy-token", response.getBody().token());
        assertEquals("john", response.getBody().username());
        assertEquals("john@example.com", response.getBody().email());
        assertTrue(response.getBody().roles().contains("ROLE_USER"));  // Match against String

        verify(authService).login(any(LoginRequest.class));
    }
}
