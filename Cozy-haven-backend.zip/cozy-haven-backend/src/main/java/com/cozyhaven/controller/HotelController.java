package com.cozyhaven.controller;

import com.cozyhaven.entity.Hotel;
import com.cozyhaven.service.HotelService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/hotels")
@CrossOrigin(origins = "http://localhost:4200")
public class HotelController {

    private final HotelService hotelService;

    public HotelController(HotelService hotelService) {
        this.hotelService = hotelService;
    }

    /* ---------- PUBLIC LIST ---------- */
    @PreAuthorize("permitAll()")            // anyone can browse hotels
    @GetMapping
    public ResponseEntity<List<Hotel>> list() {
        return ResponseEntity.ok(hotelService.findAll());
    }

    /* ---------- READ SINGLE ---------- */
    @PreAuthorize("permitAll()")            // anyone can view details
    @GetMapping("/{id}")
    public ResponseEntity<Hotel> get(@PathVariable Long id) {
        return ResponseEntity.ok(hotelService.findById(id));
    }

    /* ---------- CREATE ---------- */
    @PreAuthorize("hasRole('OWNER') or hasRole('ADMIN')")
    @PostMapping
    public ResponseEntity<Hotel> add(@RequestBody Hotel hotel) {
        return ResponseEntity.ok(hotelService.saveHotel(hotel));
    }

    /* ---------- DELETE ---------- */
    @PreAuthorize("hasRole('OWNER') or hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        hotelService.delete(id);
        return ResponseEntity.noContent().build();
    }
}
