package com.cozyhaven.service;

import com.cozyhaven.entity.Hotel;
import com.cozyhaven.entity.Room;
import com.cozyhaven.exception.ResourceNotFoundException;
import com.cozyhaven.repository.HotelRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class HotelService {

    private final HotelRepository hotelRepository;

    public HotelService(HotelRepository hotelRepository) {
        this.hotelRepository = hotelRepository;
    }

    /* ---------- create / update ---------- */
    public Hotel saveHotel(Hotel hotel) {
        hotel.getRooms().forEach(r -> r.setHotel(hotel));   // keep FK intact
        return hotelRepository.save(hotel);
    }

    /* ---------- read ---------- */
    public List<Hotel> findAll() {
        return hotelRepository.findAll();
    }

    public Hotel findById(Long id) {
        return hotelRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Hotel id " + id + " not found"));
    }

    /* ---------- delete ---------- */
    public void delete(Long id) {
        if (!hotelRepository.existsById(id)) {
            throw new ResourceNotFoundException("Hotel id " + id + " not found");
        }
        hotelRepository.deleteById(id);
    }
}
