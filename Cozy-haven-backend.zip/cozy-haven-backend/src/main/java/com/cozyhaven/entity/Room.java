package com.cozyhaven.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Room {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "hotel_id", nullable = false)
    @JsonBackReference             // ✅ prevents infinite loop
    private Hotel hotel;

    private String roomSize;
    private String bedType;
    private int    maxOccupancyBase;
    private int    maxOccupancy;
    private double baseFare;
    private boolean ac;
    private boolean available = true;

    /* -------- expose hotelId without serialising hotel again -------- */
    @JsonProperty("hotelId")       // key in JSON output
    public Long getHotelId() {
        return hotel != null ? hotel.getId() : null;
    }
}
