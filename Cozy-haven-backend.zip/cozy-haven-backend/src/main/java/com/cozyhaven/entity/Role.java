package com.cozyhaven.entity;

public enum Role {
    ROLE_USER,
    ROLE_OWNER,
    ROLE_ADMIN
}
