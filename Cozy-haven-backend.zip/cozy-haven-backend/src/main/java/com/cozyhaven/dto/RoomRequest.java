// src/main/java/com/cozyhaven/dto/RoomRequest.java
package com.cozyhaven.dto;

public record RoomRequest(
        Long hotelId,           // ID of the hotel the room belongs to
        String roomSize,
        String bedType,         // SINGLE, DOUBLE, KING, etc.
        int maxOccupancyBase,
        int maxOccupancy,
        double baseFare,
        boolean ac
) {}
