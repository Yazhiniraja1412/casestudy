package com.cozyhaven.dto;

import java.time.LocalDate;

public record BookingResponse(
    Long id,
    Long roomId,
    LocalDate checkInDate,
    LocalDate checkOutDate,
    int adults,
    int children,
    String status
) {}
